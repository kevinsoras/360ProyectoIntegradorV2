require('../dist/sweetalert2')
require('../dist/sweetalert2.all')
