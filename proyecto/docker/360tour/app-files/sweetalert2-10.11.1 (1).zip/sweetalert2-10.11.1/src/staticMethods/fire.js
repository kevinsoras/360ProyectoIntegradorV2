export function fire (...args) {
  const Swal = this
  return new Swal(...args)
}
